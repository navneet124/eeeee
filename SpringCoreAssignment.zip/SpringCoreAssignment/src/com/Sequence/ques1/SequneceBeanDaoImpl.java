package com.Sequence.ques1;

import org.springframework.jdbc.core.JdbcTemplate;

public class SequneceBeanDaoImpl implements SequneceBeanDao {

	
	
	
    JdbcTemplate jdt;

	public SequneceBeanDaoImpl() {
		super();
	}

	public SequneceBeanDaoImpl(JdbcTemplate jdt) {
		super();
		this.jdt = jdt;
	}

	public JdbcTemplate getJdt() {
		return jdt;
	}

	public void setJdt(JdbcTemplate jdt) {
		this.jdt = jdt;
	}

	@Override
	public int insert(Sequnce s) {

Object []param={s.genrator()};
		
		int n=jdt.update("insert into Sequence values(?)", param);
		
		return n;
	}


	




}

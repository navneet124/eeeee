package com.Sequence.ques1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SequnecMain {

	public static void main(String[] args) {
		 AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(
                JdbcConfiguration.class);
	SequneceBeanDaoImpl bc = applicationContext.getBean(SequneceBeanDaoImpl.class);
	Sequnce s = new Sequnce("hr", "022", "cogni");
		if(bc.insert(s)>=0){
			System.out.println("Inserted");
		}
	}

}

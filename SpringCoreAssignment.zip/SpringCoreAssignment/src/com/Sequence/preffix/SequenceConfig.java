package com.Sequence.preffix;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SequenceConfig {

	@Bean
	@Qualifier
	public Sequnce getSequnce(){
		return new Sequnce();
		
	}
	@Bean
	@Qualifier
	public PreffixGenrator getPreffixGenrator(){
		return new PreffixGenrator();
	}
}

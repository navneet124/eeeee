package com.Sequence.preffix;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PreffixTest {
	public static void main(String[] args) {
		
	ApplicationContext context = new AnnotationConfigApplicationContext( SequenceConfig.class);
	PreffixGenrator pg = new PreffixGenrator();
	//pg.setPreffix("gjhu");
	Sequnce s = (Sequnce) context.getBean(Sequnce.class);
	System.out.println(s);
	
	}	
}
